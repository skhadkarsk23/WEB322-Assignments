module.exports = {
  content: [
    './views/**/*.html',
    './public/**/*.html'
  ],
  plugins: [
    require('@tailwindcss/typography'),
    require('daisyui')
  ],
  theme: {
    extend: {},
  },
  daisyui: {
    themes: ["fantasy"],  
  },
}

